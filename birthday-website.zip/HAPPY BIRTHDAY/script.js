let currentStep = 1;

// Initialize on page load
window.onload = function() {
    createFloatingHearts();
    initConfetti();
    handleImageLoading();
};

// Navigate to next step
function nextStep(stepNumber) {
    document.getElementById(`step${currentStep}`).classList.remove('active');
    currentStep = stepNumber;
    document.getElementById(`step${currentStep}`).classList.add('active');
    
    // Special actions for specific steps
    if (stepNumber === 4) {
        typeMessage();
    }
    if (stepNumber === 8) {
        setupCandleBlow();
    }
}

// Typewriter effect for personal message with best friend vibes
function typeMessage() {
    const message = `Hey Dishaa! 🎉 On your special day, I just want you to know how grateful I am to have you as my best friend. You've been there through thick and thin, making every moment more fun and memorable. Your energy, laughter, and amazing personality light up everyone's life around you. Here's to celebrating YOU today and creating many more incredible memories together! Cheers to another fantastic year ahead! 🥳🎂`;
    
    const messageElement = document.getElementById('personalMessage');
    messageElement.textContent = message;
}

// Handle image loading with fade-in effect
function handleImageLoading() {
    const images = document.querySelectorAll('.gallery-img');
    
    images.forEach((img) => {
        // Check if image is already loaded (cached)
        if (img.complete) {
            img.classList.add('loaded');
        } else {
            // Add loaded class when image loads
            img.addEventListener('load', function() {
                this.classList.add('loaded');
            });
            
            // Handle error - keep placeholder visible
            img.addEventListener('error', function() {
                console.log('Image failed to load:', this.src);
                // Placeholder will remain visible
            });
        }
    });
}

// Setup candle blow interaction
function setupCandleBlow() {
    const candle = document.querySelector('.candle');
    const flame = document.querySelector('.flame');
    const finalMessage = document.getElementById('finalWish');
    
    candle.addEventListener('click', function() {
        flame.style.opacity = '0';
        setTimeout(() => {
            finalMessage.classList.remove('hidden');
            launchConfetti();
        }, 500);
    });
}

// Floating birthday elements in background
function createFloatingHearts() {
    const container = document.querySelector('.floating-hearts');
    const emojis = ['🎈', '🎉', '🎊', '✨', '🎁', '🌟', '💫', '🎂'];
    
    setInterval(() => {
        const element = document.createElement('div');
        element.innerHTML = emojis[Math.floor(Math.random() * emojis.length)];
        element.style.position = 'absolute';
        element.style.fontSize = Math.random() * 25 + 15 + 'px';
        element.style.left = Math.random() * 100 + '%';
        element.style.bottom = '-50px';
        element.style.animation = `floatUp ${Math.random() * 3 + 4}s linear`;
        element.style.opacity = Math.random() * 0.6 + 0.3;
        
        container.appendChild(element);
        
        setTimeout(() => {
            element.remove();
        }, 7000);
    }, 800);
}

// CSS for floating animation
const style = document.createElement('style');
style.innerHTML = `
    @keyframes floatUp {
        0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) rotate(360deg);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Confetti animation
function initConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    window.confettiParticles = [];
    
    // Resize canvas on window resize
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

function launchConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    const ctx = canvas.getContext('2d');
    const colors = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe', '#ffd700', '#ff6b6b'];
    
    for (let i = 0; i < 200; i++) {
        window.confettiParticles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height - canvas.height,
            r: Math.random() * 8 + 3,
            d: Math.random() * 12 + 5,
            color: colors[Math.floor(Math.random() * colors.length)],
            tilt: Math.random() * 10 - 10,
            tiltAngleIncremental: Math.random() * 0.07 + 0.05,
            tiltAngle: 0
        });
    }
    
    animateConfetti(ctx, canvas);
}

function animateConfetti(ctx, canvas) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    window.confettiParticles.forEach((p, index) => {
        p.tiltAngle += p.tiltAngleIncremental;
        p.y += (Math.cos(p.d) + 3 + p.r / 2) / 2;
        p.x += Math.sin(p.d);
        p.tilt = Math.sin(p.tiltAngle - index / 3) * 15;
        
        ctx.beginPath();
        ctx.lineWidth = p.r / 2;
        ctx.strokeStyle = p.color;
        ctx.moveTo(p.x + p.tilt + p.r, p.y);
        ctx.lineTo(p.x + p.tilt, p.y + p.tilt + p.r);
        ctx.stroke();
        
        if (p.y > canvas.height) {
            window.confettiParticles.splice(index, 1);
        }
    });
    
    if (window.confettiParticles.length > 0) {
        requestAnimationFrame(() => animateConfetti(ctx, canvas));
    }
}
